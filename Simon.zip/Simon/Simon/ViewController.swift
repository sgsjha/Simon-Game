//
//  ViewController.swift
//  Simon
//
//  Created by Sarthak Jha on 11/11/2023.
//

import UIKit
import AVFoundation

class ViewController: UIViewController {

    
    @IBOutlet weak var playButtonOutlet: UIButton!
    @IBAction func playButton(_ sender: Any) {
        playButtonOutlet.alpha = 0.5
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
            self.playButtonOutlet.alpha = 1
        }
        performSegue(withIdentifier: "gameStart", sender: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

