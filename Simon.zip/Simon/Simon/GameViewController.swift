//
//  GameViewController.swift
//  Simon
//
//  Created by Sarthak Jha on 11/11/2023.
//

import UIKit
import AVFoundation
let hScorekey = "HighScore"

class GameViewController: UIViewController, AVAudioPlayerDelegate {


    
    @IBAction func backButton(_ sender: Any) {
        
    }
    @IBOutlet weak var highScoreLabel: UILabel!
    
  //MARK: Restart Game button
    @IBOutlet weak var restartButtonOutlet: UIButton!
    
    @IBAction func restartButton(_ sender: Any) {
        resetGame()
        startGame()
        
        restartButtonOutlet.isHidden = true
    }
    
    //MARK: - Variable decleration
    @IBOutlet weak var pointsLabel: UILabel!
    @IBOutlet weak var levelLabel: UILabel!
    @IBOutlet weak var newHScoreLabel: UILabel!
    
    var sound1player:AVAudioPlayer!
    var sound2player:AVAudioPlayer!
    var sound3player:AVAudioPlayer!
    var sound4player:AVAudioPlayer!
    
    var points = 0
    var playlist = [Int]()
    var answerColous = [String]()
    var currentItem = 0
    var numberOfTaps = 0
    var readyforUser = false
    var level = 1
    var colours = ["Red","Yellow","Green","Blue"]
    var buttonPressed:String = ""
    
    let userDefault = UserDefaults.standard
    var highScore: Int {
        
        get {
            return userDefault.integer(forKey: hScorekey)
        }
        set {
            userDefault.set(newValue, forKey: hScorekey)
            userDefault.synchronize()
            highScoreLabel.text = "HIGH SCORE: \(newValue)"
        }
    }
    
    // MARK: - Colour buttons
    @IBOutlet weak var redButtonOutlet: UIButton!
    @IBOutlet weak var yellowButtonOutlet: UIButton!
    @IBOutlet weak var greenButtonOutlet: UIButton!
    @IBOutlet weak var blueButtonOutlet: UIButton!
    
    
    @IBAction func redButton(_ sender: Any) {
        
        redButtonOutlet.alpha = 0.5
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
            self.redButtonOutlet.alpha = 1
        }
      buttonPressed = "Red"
      print("\(buttonPressed) was tapped")
      sound1player.play()
      checkifCorrect(buttonPressed: 1)
    }
    
    
    @IBAction func yellowButton(_ sender: Any) {
        yellowButtonOutlet.alpha = 0.5
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
            self.yellowButtonOutlet.alpha = 1
        }
        buttonPressed = "Yellow"
        print("\(buttonPressed) was tapped")
        sound2player.play()
        checkifCorrect(buttonPressed: 2)
    }
    
    
    @IBAction func greenButton(_ sender: Any) {
        greenButtonOutlet.alpha = 0.5
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
            self.greenButtonOutlet.alpha = 1
        }
        buttonPressed = "Green"
        print("\(buttonPressed) was tapped")
        sound3player.play()
        checkifCorrect(buttonPressed: 3)
    }
    
    @IBAction func blueButton(_ sender: Any) {
        blueButtonOutlet.alpha = 0.5
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
            self.blueButtonOutlet.alpha = 1
        }
        buttonPressed = "Blue"
        print("\(buttonPressed) was tapped")
        sound4player.play()
        checkifCorrect(buttonPressed: 4)
    }
    
    
   //MARK: - Start Game functions
    func startGame() {
        let randomNum = Int.random(in: 1...4)
        playlist.append(randomNum)
        answerColous.append(colours[randomNum - 1])
        print(answerColous)
        levelLabel.text = "Level \(level)"
        pointsLabel.text = "\(points)"
        newHScoreLabel.isHidden = true
        playNextLevel()
        
    }
    //MARK: - Audio Function
    func setupAudioFiles() {
        let soundFilePath1 = Bundle.main.path(forResource: "red",ofType: "mp3")
        let soundFileURL1 = NSURL(fileURLWithPath: soundFilePath1!)
        
        let soundFilePath2 = Bundle.main.path(forResource: "yellow",ofType: "mp3")
        let soundFileURL2 = NSURL(fileURLWithPath: soundFilePath2!)
        
        let soundFilePath3 = Bundle.main.path(forResource: "green",ofType: "mp3")
        let soundFileURL3 = NSURL(fileURLWithPath: soundFilePath3!)
        
        let soundFilePath4 = Bundle.main.path(forResource: "blue",ofType: "mp3")
        let soundFileURL4 = NSURL(fileURLWithPath: soundFilePath4!)
        
        do {
            try sound1player = AVAudioPlayer(contentsOf: soundFileURL1 as URL)
            try sound2player = AVAudioPlayer(contentsOf: soundFileURL2 as URL)
            try sound3player = AVAudioPlayer(contentsOf: soundFileURL3 as URL)
            try sound4player = AVAudioPlayer(contentsOf: soundFileURL4 as URL)
            
            
        } catch {
            print(error)
        }
        
        sound1player.delegate = self
        sound2player.delegate = self
        sound3player.delegate = self
        sound4player.delegate = self
        
        sound1player.numberOfLoops = 0
        sound2player.numberOfLoops = 0
        sound3player.numberOfLoops = 0
        sound4player.numberOfLoops = 0
    }
    
   
    func audioPlayerDidFinishPlaying(_ player: AVAudioPlayer, successfully flag: Bool) {
        
        if currentItem <= playlist.count - 1 {
            // play our next item
            playNextLevel()
        } else {
            readyforUser = true
            resetButton()
            // enable buttons
        }
    }
    
    //MARK: - Game logic
    func checkifCorrect (buttonPressed:Int) {
        if buttonPressed == playlist[numberOfTaps] {
            
            if numberOfTaps == playlist.count - 1 {
                points += 1
                if points > highScore {
                    highScore = points
                    highScoreLabel.text = "HIGH SCORE: \(highScore)"
                    newHScoreLabel.isHidden = false
                }
                pointsLabel.text = "\(points)"
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) {
                    self.nextRound()
                } // end of dispatch
                
                return
                
            }
            numberOfTaps += 1
        } else{
            // reset game
            resetGame()
        }
    }
    
    // Reset Games when player loses
    func resetGame() {
        level = 1
        
        points = 0
        readyforUser = false
        numberOfTaps = 0
        currentItem = 0
        playlist = []
        levelLabel.text = "GAME OVER"
        restartButtonOutlet.isHidden = false
    }
    // Play the next round
    func nextRound() {
        level += 1
        levelLabel.text = "Level \(level)"
        readyforUser = false
        numberOfTaps = 0
        currentItem = 0
        let randomNum = Int.random(in: 1...4)
        playlist.append(randomNum)
        answerColous.append(colours[randomNum - 1])
        print(answerColous)
        playNextLevel()
        // disable buttons
    }
    
    
    //MARK: - Highlight Buttons
        func highlightButton (colour:String) {
            
            switch colour {
            case "Red":
                redButtonOutlet.setImage(UIImage(named: "redPressed"), for: .normal)
                DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                    self.resetButton()
                }
                
                
                
            case "Yellow":
                yellowButtonOutlet.setImage(UIImage(named: "yellowPressed"), for: .normal)
                DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                    self.resetButton()
                }
            
                
                
            case "Green":
                greenButtonOutlet.setImage(UIImage(named: "greenPressed"), for: .normal)
                DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                    self.resetButton()
                }
                
               
                
                
            case "Blue":
                blueButtonOutlet.setImage(UIImage(named: "bluePressed"), for: .normal)
                
                DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                    self.resetButton()
                }
            default : break
            }
        }
        
        
     //MARK: - Play next level
    func playNextLevel() {
        let selectedItem = playlist[currentItem]
        
        switch selectedItem {
        case 1:
            highlightButton(colour: "Red")
            sound1player.play()
            break
        case 2:
            highlightButton(colour: "Yellow")
            sound2player.play()
            break
        case 3:
            highlightButton(colour: "Green")
            sound3player.play()
            break
        case 4:
            highlightButton(colour: "Blue")
            sound4player.play()
            break
        default : 
            break
        }
        
        currentItem += 1
    }
           
        
        
        func resetButton() {
            redButtonOutlet.setImage(UIImage(named: "red"), for: .normal)
            yellowButtonOutlet.setImage(UIImage(named: "yellow"), for: .normal)
            greenButtonOutlet.setImage(UIImage(named: "green"), for: .normal)
            blueButtonOutlet.setImage(UIImage(named: "blue"), for: .normal)
        }
        
  //MARK: - View did load
    override func viewDidLoad() {
        super.viewDidLoad()
        setupAudioFiles()
        startGame()
        highScoreLabel.text = "HIGH SCORE: \(highScore)"
        restartButtonOutlet.isHidden = true

        // Do any additional setup after loading the view.
    }
    


}
